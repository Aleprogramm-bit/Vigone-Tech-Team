HTML Creator
Questo editor è comodo, funzionale ma non modifica tutto.
E' solo uno strumento per creare le basi, ma voi dovrete pensare a modificarlo benissimo.
Puoi solo creare pulsanti, card (pulsanti con immagine e descrizione), immagini, titolo e paragrafo; ma non modificare HTML già creati.
Tutto qui, adesso è tutto, vi auguro buona creazione!!!!