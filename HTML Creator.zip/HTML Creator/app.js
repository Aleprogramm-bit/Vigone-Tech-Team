const canvas = document.getElementById('canvas');
const propPanel = document.getElementById('propPanel');
let selected = null;

/* ---------------- INIZIALIZZA PRIMA PAGINA ---------------- */
addPage();

/* ---------------- PAGINE ORIZZONTALI ---------------- */

function addPage() {
  const page = document.createElement('div');
  page.className = 'page';
  canvas.appendChild(page);

  // FIX: scroll automatico alla nuova pagina
  canvas.scrollLeft = canvas.scrollWidth;
}


function getCurrentPage() {
  return canvas.lastElementChild;
}

/* ---------------- CREAZIONE BLOCCHI ---------------- */

function addBlock(type) {
  const page = getCurrentPage();
  if (!page) return;

  const wrapper = document.createElement('div');
  wrapper.className = 'block';

  const del = document.createElement('div');
  del.className = 'delete-btn';
  del.textContent = 'X';
  del.onclick = () => wrapper.remove();

  const menuImg = document.createElement('div');
  menuImg.className = 'menu-img';
  menuImg.textContent = 'IMG';
  menuImg.onclick = () => openImagePicker(wrapper);

  const menuHtml = document.createElement('div');
  menuHtml.className = 'menu-html';
  menuHtml.textContent = 'HTML';
  menuHtml.onclick = () => openHTMLPicker(wrapper);

  const el = document.createElement(type);
  el.contentEditable = (type !== 'img');

  if (type === 'h1') el.textContent = 'Titolo';
  if (type === 'p') el.textContent = 'Paragrafo...';
  if (type === 'button') el.textContent = 'Apri pagina';
  if (type === 'img') {
    el.src = 'https://via.placeholder.com/400x200';
    el.style.width = '100%';
    el.style.height = 'auto';
    el.style.objectFit = 'cover';
  }

  wrapper.appendChild(del);
  wrapper.appendChild(menuImg);
  wrapper.appendChild(menuHtml);
  wrapper.appendChild(el);

  addResize(wrapper);
  page.appendChild(wrapper);

  wrapper.onclick = () => selectBlock(wrapper);
}

/* ---------------- CARD ---------------- */

function addCard() {
  const page = getCurrentPage();
  if (!page) return;

  const wrapper = document.createElement('div');
  wrapper.className = 'block';

  const del = document.createElement('div');
  del.className = 'delete-btn';
  del.textContent = 'X';
  del.onclick = () => wrapper.remove();

  const menuImg = document.createElement('div');
  menuImg.className = 'menu-img';
  menuImg.textContent = 'IMG';
  menuImg.onclick = () => openImagePicker(wrapper);

  const menuHtml = document.createElement('div');
  menuHtml.className = 'menu-html';
  menuHtml.textContent = 'HTML';
  menuHtml.onclick = () => openHTMLPicker(wrapper);

  const img = document.createElement('img');
  img.src = 'https://via.placeholder.com/300x150';
  img.style.width = '100%';

  const title = document.createElement('h3');
  title.textContent = 'Titolo card';
  title.contentEditable = true;

  const text = document.createElement('p');
  text.textContent = 'Descrizione card...';
  text.contentEditable = true;

  wrapper.appendChild(del);
  wrapper.appendChild(menuImg);
  wrapper.appendChild(menuHtml);
  wrapper.appendChild(img);
  wrapper.appendChild(title);
  wrapper.appendChild(text);

  addResize(wrapper);
  page.appendChild(wrapper);

  wrapper.onclick = () => selectBlock(wrapper);
}

/* ---------------- MENU IMMAGINE ---------------- */

function openImagePicker(wrapper) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = "image/*";
  input.onchange = () => {
    const file = input.files[0];
    if (!file) return;

    const url = URL.createObjectURL(file);

    const img = wrapper.querySelector('img');
    if (img) img.src = url;
    else {
      const newImg = document.createElement('img');
      newImg.src = url;
      newImg.style.width = '100%';
      wrapper.appendChild(newImg);
    }
  };
  input.click();
}

/* ---------------- MENU HTML ---------------- */

function openHTMLPicker(wrapper) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = ".html,.htm";
  input.onchange = () => {
    const file = input.files[0];
    if (!file) return;

    const url = URL.createObjectURL(file);

    const el = [...wrapper.children].find(c => c.tagName !== 'DIV');

    let a = wrapper.querySelector('a');
    if (!a) {
      a = document.createElement('a');
      wrapper.insertBefore(a, el);
      a.appendChild(el);
    }

    a.href = url;
    a.target = "_blank";
  };
  input.click();
}

/* ---------------- RESIZE SOPRA + SOTTO ---------------- */

function addResize(block) {
  const top = document.createElement('div');
  top.className = 'resize-top';

  const bottom = document.createElement('div');
  bottom.className = 'resize-bottom';

  block.appendChild(top);
  block.appendChild(bottom);

  top.addEventListener('mousedown', e => startResize(e, block, "top"));
  bottom.addEventListener('mousedown', e => startResize(e, block, "bottom"));
}

function startResize(e, block, side) {
  e.preventDefault();
  const startY = e.clientY;
  const startH = block.offsetHeight;
  const startTop = block.offsetTop;

  window.onmousemove = ev => {
    const diff = ev.clientY - startY;

    if (side === "bottom") {
      block.style.height = (startH + diff) + "px";
    } else {
      block.style.height = (startH - diff) + "px";
      block.style.top = (startTop + diff) + "px";
    }

    const img = block.querySelector('img');
    if (img) {
      img.style.height = block.style.height;
      img.style.width = block.style.width;
    }
  };

  window.onmouseup = () => window.onmousemove = null;
}

/* ---------------- PROPRIETÀ ---------------- */

function selectBlock(block) {
  selected = block;
  const el = [...block.children].find(c => c.tagName !== 'DIV');

  if (!el) return;

  propPanel.innerHTML = `
    <label>Font size</label>
    <input type="number" value="${parseInt(el.style.fontSize) || 16}"
           oninput="updateStyle('fontSize', this.value + 'px')">

    <label>Colore testo</label>
    <input type="color"
           oninput="updateStyle('color', this.value)">

    <label>Font family</label>
    <select onchange="updateStyle('fontFamily', this.value)">
      <option value="sans-serif">Sans</option>
      <option value="serif">Serif</option>
      <option value="monospace">Mono</option>
    </select>

    <label>Allineamento</label>
    <select onchange="updateStyle('textAlign', this.value)">
      <option value="left">Sinistra</option>
      <option value="center">Centro</option>
      <option value="right">Destra</option>
    </select>
  `;
}

function updateStyle(prop, value) {
  const el = [...selected.children].find(c => c.tagName !== 'DIV');
  if (!el) return;
  el.style[prop] = value;
}

/* ---------------- SFONDO ---------------- */

function changeBackground() {
  const inputImg = document.createElement('input');
  inputImg.type = 'file';
  inputImg.accept = "image/*";

  inputImg.onchange = () => {
    const file = inputImg.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    document.body.style.backgroundImage = `url('${url}')`;
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundColor = "";
  };

  const inputColor = document.createElement('input');
  inputColor.type = 'color';

  inputColor.onchange = () => {
    document.body.style.backgroundImage = "";
    document.body.style.backgroundColor = inputColor.value;
  };

  inputImg.click();
  inputColor.click();
}

/* ---------------- EXPORT ---------------- */

function exportHTML() {
  const pages = canvas.querySelectorAll('.page');
  let html = '';

  pages.forEach(page => {
    const clone = page.cloneNode(true);

    clone.querySelectorAll('.delete-btn').forEach(e => e.remove());
    clone.querySelectorAll('.menu-img').forEach(e => e.remove());
    clone.querySelectorAll('.menu-html').forEach(e => e.remove());
    clone.querySelectorAll('.resize-top').forEach(e => e.remove());
    clone.querySelectorAll('.resize-bottom').forEach(e => e.remove());

    html += `<div class="page">${clone.innerHTML}</div>\n`;
  });

  const fullPage =
`<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Sito esportato</title>
  <style>
    body {
      display:flex;
      overflow-x:auto;
      gap:20px;
      background:${document.body.style.backgroundColor || "none"};
      background-image:${document.body.style.backgroundImage || "none"};
      background-size:cover;
    }
    .page {
      min-width:600px;
      padding:20px;
      border:1px solid #ccc;
    }
  </style>
</head>
<body>
${html}
</body>
</html>`;

  const blob = new Blob([fullPage], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'sito.html';
  a.click();
  URL.revokeObjectURL(url);
}
