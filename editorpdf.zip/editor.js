document.getElementById("pdfInput").addEventListener("change", function () {
    const file = this.files[0];
    if (!file) return;

    const url = URL.createObjectURL(file);

    // Mostra il PDF nel viewer
    document.getElementById("pdfViewer").src = url;

    // Se il tuo editor ha già funzioni di modifica,
    // qui puoi passare "url" al tuo codice di editing.
});
